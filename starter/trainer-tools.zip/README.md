# Private trainer analysis tools

Read COACH-HANDBOOK.md for schemas, model assumptions, research workflow, and examples.
Python 3.10+; standard library only. Run from this extracted folder.

python scripts/audit_week.py --help
python scripts/analyze_weight_history.py --help
python scripts/import_research.py --help

Choose your private notebook or workspace explicitly. Audit and weight analysis are read-only; research import writes preserved source bytes and a note only to the chosen private workspace. No networking, automatic plan changes, or background tasks.
